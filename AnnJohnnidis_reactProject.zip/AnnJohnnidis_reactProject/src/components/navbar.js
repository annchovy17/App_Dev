import React from "react";
import { Outlet, Link } from "react-router-dom";

const Navbar = function(){
    return(
        <>
            <nav className='ui raised very padded segment' style={{overflow:'auto'}}>
                <h2 className='ui left floated header' style={{display:'inline-flex'}}><a href="/">Ann J. React Project</a></h2>
                <div className='ui right floated header'>
                    <button className='ui button'><Link to='/'>Home</Link></button>
                    <button className='ui button'><Link to='/searchimg'>Image Searcher</Link></button>
                    <button className='ui button'><Link to='/location'>Geolocation</Link></button>
                    <button className='ui button'><Link to='/contact'>Contact Us</Link></button>
                </div>
            </nav>
            <Outlet />
        </>
    )
}

export default Navbar;