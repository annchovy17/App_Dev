import React from "react";
import { useState } from "react";

const Contactform = function(){

    const [inputs, setInputs] = useState({})

    const handleChange = function(event){
        const name = event.target.name
        const value = event.target.value
        setInputs(values =>({
            ...values, [name]:value
        }))
    }

  {/* -- select data -- */}
    const [myGender, setGender] = useState('female')
    const selectedGender = function(event){
       setGender(event.target.value) 
    }
  {/* -- textarea -- */}
    const [textComments, setTextarea] = useState('')
    const submitComment = function(event){
        setTextarea(event.target.value)
    }
  {/* -- submit form -- */}
    const submitForm = function(event){
        event.preventDefault();
        let innertext = document.querySelector('.innertext')
        innertext.innerHTML = `Name: ${inputs.username} <br> Age: ${inputs.enteredAge} <br >Gender: ${myGender} <br> Comments: ${textComments}`
    }
    return(
        <div className='ui raised very padded text container segment' style={{marginTop:'3em'}}>
            <form className='ui form' onSubmit={submitForm}>
                <fieldset>
                    <legend className='ui header'>Contact form</legend>
                    <label for='name'>Enter your name: </label>
                    <input 
                        id='name'
                        name='username'
                        type='text'
                        placeholder="Enter your name.."
                        value={inputs.username}
                        onChange={handleChange}
                    />
                    <label for='age'>Enter age: </label>
                    <input  
                        type='number'
                        id='age'
                        name='enteredAge'
                        value={inputs.enteredAge}
                        onChange={handleChange}    
                    />
                {/* -- select gender -- */}
                    <div style={{marginTop:'1em'}}>
                        <label>Select gender: 
                            <select value={myGender} onChange={selectedGender}>
                                <option value='female'>Female</option>
                                <option value='male'>Male</option>
                                <option value='other'>Other</option>
                            </select>
                        </label>
                    </div>
                {/* -- textarea -- */}
                    <div style={{marginTop:'1em'}}>
                        <textarea 
                            value={textComments} 
                            onChange={submitComment}
                            placeholder="Type comments.."
                        />
                    </div>
                {/* -- submit form -- */}
                    <div style={{marginTop:'1em'}}>
                        <input type='submit' className='ui button' />
                    </div>
                </fieldset>
            </form>
            <div>
            <p className="innertext"></p>
            </div>
        </div>
    )
}

export default Contactform;