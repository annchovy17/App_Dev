import React from "react";
import southernImg from './images/southern.jpg'
import northernImg from './images/northern.jpg'
import equatorialImg from './images/equator.webp'

const Hemisphere_Display = (props) => {
    const hemisphereResult = props.latitude
    let userLocation=''
    let picture
    if(hemisphereResult>0){
        userLocation='in the Northern Hemisphere!'
        picture = northernImg
    }
    else if(hemisphereResult<0){
        userLocation='in the Southern Hemisphere!'
        picture = southernImg
    }
    else{
        userLocation='at the Equatorial line!'
        picture = equatorialImg
    }
    return (
        <div>
            <h1 style={{textAlign:'center'}}>Welcome to hemisphere app</h1>
            <div className='ui raised very padded text container segment geoBox'>
            <p className="locationText">You are <span>{userLocation}</span></p>
            <img className="hemisphereImg" src={picture} style={{width:'40%'}}/>
            </div>
        </div>
    )
}

export default Hemisphere_Display;