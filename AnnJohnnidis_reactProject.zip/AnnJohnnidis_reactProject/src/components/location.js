import React from "react";
import Hemisphere_Display from "./hemisphere";

class Geolocation extends React.Component{
    state={ latitude: ""}

    componentDidMount(){
        window.navigator.geolocation.getCurrentPosition(
            (position) =>{
                this.setState({ latitude: position.coords.latitude })
            }
        )
    }
    render(){

        return(
            <div style={{marginTop:'3em'}}>
            <Hemisphere_Display latitude={this.state.latitude} />
            </div>
        )
    }
}

export default Geolocation;