import React from "react";
import image from"../components/images/imagesearch.png"
import map from "../components/images/map.png"
import avocado from "../components/images/avatar_avocado.svg"
import tiktok from "../components/images/tiktok_logo.svg"
import twitter from "../components/images/twitter_logo.svg"

const Home = function(){
    return(
    <div>
            <div className="mainBox">
                <div className="card">
                    <a href="/searchimg"><img src={image} /></a>
                    <h3 className="title">Image Search</h3>
                    <p className="text">Search for images from around the web
                    </p>
                    <a href="/searchimg">Visit the app</a>
                </div>

                <div className="card">
                    <a href="/location"><img src={map} /></a>
                    <h3 className="title">Geolocation</h3>
                    <p className="text">Geolocation app detects where in the world you are and displays the hemipshere
                    </p>
                    <a href="/location">Visit the app</a>
                </div>

                <div className="card">
                    <a href="/contact"><img src={avocado} /></a>
                    <h3 className="title">Contact Us</h3>
                    <p className="text">Drop us a line!
                    </p>
                    <a href="/contact">Visit the app</a>

                </div>
            </div>
            <footer>
                <p style={{marginLeft:'2%', display:'inline'}}>Ann Johnnidis project 1</p>
                <div className="links">
                    <a href="https://www.tiktok.com/explore" target="_blank" rel="noopener noreferrer">                        
                        <img src={tiktok} />
                    </a>
                    <a href="https://twitter.com/home" target="_blank" rel="noopener noreferrer">
                        <img src={twitter} />
                    </a>
                </div>
            </footer>
        </div>
    )
}

export default Home;