import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/home";
import Geolocation from "./components/location";
import Contactform from "./components/contact";
import Navbar from "./components/navbar";
import Searchimg from "./components/searchimg";

const App = function(){
    return(
        <div className='App'>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Navbar/>}>
                        <Route index element={<Home/>}/>
                        <Route path='/searchimg' element={<Searchimg/>} />
                        <Route path="/location" element={<Geolocation/>} />
                        <Route path="/contact" element={<Contactform/>} />

                    </Route>
                </Routes>
            </BrowserRouter>
        </div>
    )
}

export default App;