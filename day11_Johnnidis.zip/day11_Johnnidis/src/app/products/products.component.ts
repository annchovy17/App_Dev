import { Component } from '@angular/core';

@Component({
    selector:'products', //selecting a <products></products> tag
    templateUrl: './products.component.html' // templateURL is where I am going to find the selector element, the location
})

export class ProductsComponent{

}