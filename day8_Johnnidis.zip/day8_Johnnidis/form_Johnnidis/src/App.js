import React from "react";
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import About from './components/about'
import Home from './components/home'
import Contact from './components/contact'
import Form from './components/Form'
import Navbar from './components/navbars'


const App = function(){
    return(
        <div className='App'>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Navbar/>}>
                        <Route index element={<Home/>}/>
                        <Route path="/about" element={<About/>} />
                        <Route path="/contact" element={<Contact/>} />
                        <Route path="/form" element={<Form/>} />
                    </Route>
                </Routes>
            </BrowserRouter>
        </div>
    )
}

export default App;