import React from "react";

const Contact= function(){
    return(
        <div className='ui raised very padded text container segment' style={{marginTop:'3em'}}>
            <h2 className='ui header'>Contact us</h2>
            <p>Some text for contacting us</p>
        </div>
    )
}

export default Contact;