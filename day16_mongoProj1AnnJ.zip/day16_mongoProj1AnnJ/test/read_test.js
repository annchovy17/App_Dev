const assert = require('assert')
const Student = require('../src/students')

describe('Read data', ()=>{
    let student1, student2, student3

    // beforeEach is going to go review the actions that I have done in my code
    // beforeEach action? I want to make sure student named Peter was created
    beforeEach((done)=>{
        student1 = new Student({name: 'Peter'})
        student2 = new Student({name: 'Martha'})
        student3 = new Student({name:'Peter'})
        student1.save()
        student2.save()
        student3.save()
        .then(()=>{done()})
    })

    /*
    // it pushes into query list
    it('Find all students with name Peter', async ()=>{
        const students = await Student.find({name:'Peter'})
        assert(students[0]._id.toString() === student1._id.toString())
    })
    */
   it('Find one Peter', async ()=>{
        const students = await Student.findOne({_id:student1._id})
        assert(students.name === 'Peter')
   })

})