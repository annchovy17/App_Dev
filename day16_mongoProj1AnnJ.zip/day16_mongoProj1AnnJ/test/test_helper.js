// import mongoose
const mongoose = require('mongoose')

// connect to database, student_test is the db name
mongoose.connect('mongodb://localhost/students_test')

// check if it is connected
mongoose.connection
    //.once method watches for mongoDB to connect the first time once an event occured
    .once('open',()=>{
        console.log('\n ----- Connected to mongoDB ----- \n')
    })
    //.on method watches for errors in the connection
    .on('error', (e)=>{
        console.log('Error connecting...', e)
    })

    // clear previous db actions
    // before each method is a hook, it will run before each test
    beforeEach((done)=>{
        mongoose.connection.collections.students.drop()
        done()
    })
    