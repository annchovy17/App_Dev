// assert is used to compare two boolean values. It is used in mocha to test data before sending data to the db. If assert returns true, data will be sent to the db
const assert = require('assert')
const Student = require('../src/students')

// create description function to help us describe what were doing in our db
describe('Create the first data', (done)=>{
    //it pushes data into the list
    it('save the student', ()=>{
        // create the new student
        const student1 = new Student({name:'Peter'})
        // create & save the new student in the db
        student1.save()
        .then(()=>{
            assert(!student1.isNew)
            done()
        })
    })
})