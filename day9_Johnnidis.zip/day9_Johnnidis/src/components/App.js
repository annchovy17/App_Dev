import React from "react";
import axios from "axios";
import Search_Input from "./Searchinput";
import Images_List from './ImageList'

class App extends React.Component{
    // set a state to store the response images in an array
    state ={images:[]}

    onSearchSubmit = async (entry) =>{
        const response = await axios.get(`https://pixabay.com/api/?key=38839917-5a87584d2c5ec28a5c260b4f6&q=${entry}&image_type=photo`)
        // setState to collect and transfer images
        this.setState({images:response.data.hits})
    }
    render(){
        return(
            <div className='ui container' style={{marginTop:'2em'}}>
                <h1 className='ui title' style={{textAlign:'center', color:'orange'}}>Welcome to image search App</h1>
                <Search_Input onSearchSubmit={this.onSearchSubmit}/>
                <p>There are {this.state.images.length}</p>
                <Images_List images={this.state.images} />
            </div>
            )
    }
}


export default App;