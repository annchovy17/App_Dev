from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# connection from form to the database
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql+psycopg2://postgres:password@localhost/quotes'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# transferring data from form to database
db = SQLAlchemy(app)

# create a model to quotes db
class Favquotes(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    author = db.Column(db.String(30))
    quote = db.Column(db.String(2000))
    date = db.Column(db.Date)

with app.app_context():
    db.create_all()

@app.route('/')
def index():
    result = Favquotes.query.all()
    return render_template('index.html', result=result)


@app.route('/about')
def about():
    return '<h1>About us</h1>'

@app.route('/quotes')
def quotes():
    return render_template('quotes.html')

@app.route('/process', methods=['POST'])
def process():
    author = request.form['author']
    quote = request.form['quote']
    date = request.form['date']
    quotedata = Favquotes(author=author, quote=quote, date=date)
    db.session.add(quotedata)
    db.session.commit()
    return redirect(url_for('index'))
