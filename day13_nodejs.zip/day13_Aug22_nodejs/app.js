const user = require('./mod')
// console.log(user('Peter'))
console.log(user.helper('Peter'))
console.log(user.id('123'))
console.log(user.email('peterpan@neverland.com'))


/*
function callColor(innerfunction){
    innerfunction()
}
let color = function(){
    console.log('Passing a function')
}
console.log(callColor(color))

let count = 0

const timer = setInterval(()=>{
    count +=2
    console.log(`counting = ${count} seconds`)
    if (count== 10){
        clearInterval(timer)
    }
}, 2000);

// glocal objects
setTimeout(()=>{
    console.log('Welcome to nodejs')
},3000)

// console module
console.warn('WARNING! error in the code')
console.error('ERROR! Syntax error at line 5')
console.trace('Trace the code below')
*/