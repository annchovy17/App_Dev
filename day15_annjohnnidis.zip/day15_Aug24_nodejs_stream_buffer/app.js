// ----- STREAMS AND BUFFERS ------
const fs = require('fs')
//import the http module
const http = require('http')

// create a readable stream to read file readme.txt. This will fill up the buffer
// const readStream = fs.createReadStream('index.html')
const writestream = fs.createWriteStream('write.txt')

// create server
const server = http.createServer((request, response)=>{
    response.writeHead(200, { 'Content-Type': 'text/html' });
    const url = request.url
    // routing in nodejs
    if(url==='/home' || url==='/'){
        fs.createReadStream('index.html').pipe(response)
    }
    else if(url==='/about'){
        fs.createReadStream('about.html').pipe(response)
    }
    else{
        fs.createReadStream('404.html').pipe(response)
    }

    // piping
    // readStream.pipe(response)
    // readStream.pipe(response)
})

// server listening to port 3000 (you can use any port)
server.listen((3000),()=>{
    console.log('Server is running at localhost:3000')
})


/*
// listen to the stream to read file readme.txt. This will fill up the buffer:
readStream.on('data', (d)=>{
    console.log('\n------------------- new data received --------------- \n')
    console.log(d)
    console.log('\n----------------------------------------------------- \n')
    writestream.write(d)
})

readStream.on('open', ()=>{
    console.log('\n\nStream opened')
})

readStream.on('end',()=>{
    console.log('Stream closed....\n\n')
})

// writestream
const writestream = fs.createWriteStream('write.txt')
writestream.write('Streaming text content\n','utf-8')

*/



/*
// ----- CREATING A SERVER IN NODEJS ------
//import the http module from nodejs. The var is usally named the same as the module
const http = require('http')

// creating server
const server = http.createServer((request, response)=>{
    // sending the response
    response.write("This is the response from the server")
    response.end('\n------ end -------\n')
    console.log(request.url)
})

// server listening to port 3000 (you can use any port)
server.listen((3000),()=>{
    console.log('Server is running at localhost:3000')
})
*/
