Data about New York City
New York City comprises 5 boroughs sitting where the Hudson River meets the Atlantic Ocean. At its core is Manhattan, a densely populated borough that’s among the world’s major commercial, financial and cultural centers. Its iconic sites include skyscrapers such as the Empire State Building and sprawling Central Park. Broadway theater is staged in neon-lit Times Square. ― Google
Weather: 68°F (20°C), Wind S at 3 mph (5 km/h), 87% Humidity More on weather.com
Local time: Thursday 6:09 PM
Population: 8.468 million (2021)
Mayor: Eric Adams
Area codes: Area code 212, Area code 917, Area code 718, Area code 646
Land area: 302.6 mi²
Elevation: 33′