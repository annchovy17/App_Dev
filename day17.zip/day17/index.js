const express = require('express')
const bodyParse = require('body-parser')
const mongoose = require('mongoose')

// create app using express
const app = express()

app.use(bodyParse.json())
app.use(express.static('public'))
app.use(bodyParse.urlencoded({extended: true}))

// connect database
mongoose.connect('mongodb://localhost/userlogin',{useNewUrlParser: true, useUnifiedTopology: true})

// check connection
const db = mongoose.connection
db.once('open', ()=>{console.log('Connected to db...')})
db.on('error', (error)=>{console.log('Error connecting... ', error)})

// create loading page
app.get('/', (req,res)=>{
    res.redirect('index.html')
}).listen(3000)

// posting the form
app.post('/login', (request, response)=>{
    try {
        // get data from index.html
        const username = request.body.username
        const password = parseInt(request.body.password)
        // parseInt because the password is saved as an integer in mongodb

        // test that the app is reading the username and password
        // console.log(`entered username = ${username} entered password ${password}`)

        // get data from database. users is the name from mongodb
        const usermail = db.collection('users').findOne({username:username}, (err,res)=>{
            if(res===null){
                response.send('Information does not match')
            }
            else if(err){
                throw err
            }

            if(res.password === password){
                console.log('Login successful!')
                return response.redirect('login.html')
            }
            else{
                console.log('password does not match')
                response.send('PASSWORD DOES NOT MATCH!')
            }
        })
    } catch (error) {
        console.log('Invalid information')
    }
})