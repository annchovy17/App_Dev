import React from 'react';
import ReactDOM from 'react-dom/client';
import User from './comments'
import avatarAvocado from './images/avatar_avocado.svg'
import avatarGranny from './images/avatar_granny.svg'
import avatarCloud from './images/avatar_cloud.svg'
import User_feedback from './UserFeedback'


const App = function(){
  return(
    <div className='ui comments'>
      <User_feedback>
        <User 
          name='Ms. Ava' 
          date='8:30AM'
          msg="I'm a talking avocado!!"
          picture={avatarAvocado}
        />
      </User_feedback>
      <User_feedback>
        <User 
          name='Mrs. Cookie' 
          date='10:26AM'
          msg='I love cookies so much that I legally changed my name.'
          picture={avatarGranny}
        />
      </User_feedback>
      <User_feedback>
        <User 
          name='Mr. Cloud' 
          date='01:52PM'
          msg='I make it rain. But I also make rainbows!'
          picture={avatarCloud}
        />
      </User_feedback>

          <h1>Blogs</h1>
          <p class="moreInfo">Helpful information for pet owners</p>
          <div class="ui container four column grid">           
        <section className="ui card">

                <p class="paragraph1">Stay up to date on vaccinations</p>
                <p>It's very important to kept your pet up to date on vaccinations.</p>
        </section>
        <section class="ui card">
            <div class="cardInfo2">
                <p class="paragraph1">Staying cool during the summer</p>
                <p>Tips on how to keep your pet cool as a cucumber</p>
            </div>
        </section>
        <section class="ui card">
            <div class="cardInfo2">
                <p class="paragraph1">Do-It-Yourself dog house</p>
                <p>Follow these step by step instructions to make your own dog house!</p>
            </div>
        </section>
        <section class="ui card">
            <div class="cardInfo2">
                <p class="paragraph1">Homemade dog food recipes</p>
                <p>Make healthy homemade meals for your pet</p>
            </div>
        </section>
    </div>
  </div>

  )
}

// rooting
const root = ReactDOM.createRoot(document.querySelector('#root'))
root.render(App())


/*
// ---- example of props
const App = function(props){
    return (
      <div>
        <h1>Welcome to React function components{ props.name }</h1>
      </div>
    )
}

// create a props in a constant
const myElement = <App name='Martha' />

// rooting and running the app
ReactDOM.render(
  myElement, document.querySelector('root')
)
*/