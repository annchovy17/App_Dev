import React from 'react';

const my_cards = function(props){
    return(
        <div className='ui card'>
            <div className='content'>
                <div className='header'>Name of user</div>
                <div className='description'>{props.children}</div>
            </div>
            <div className='ui bottom button'>
                <i className='add icon' style={{display:'block', width:'100%'}}>Add Feedback</i>
            </div>
        </div>
    )
}


// const my_cards = function(props){
//     return(
//         <div className="ui container four column grid">
//             <section className="ui card">
//                 <a href='' className='avatar'>
//                     <img src={props.picture} alt='img'/>
//                 </a>
//                 <p className='text'>Stay up to date on vaccinations</p>
//                 <p className='text'>It's very important to kept your pet up to date on vaccinations.</p>
//             </section>
//         </div>
//     )
// }

export default my_cards