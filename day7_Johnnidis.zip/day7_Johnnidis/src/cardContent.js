import React from 'react'


const card_content = function(props){
    return(
        <div className='comment'>
            <a href='' className='avatar'>
                <img src={props.picture} alt='avatar of an avocado'/>
            </a>
            <div className='content'>
                <a className='author'>
                    {props.name}
                </a>
                <div className='metadata'>
                    <span className='date'>Today at {props.date}</span>
                </div>
                <div className='text'>
                    {props.msg}
                </div>
            </div>
        </div>
    )
}

/*
const card_content = function(props){
    return(
        <div className="ui container four column grid">
        <p>testing</p>
        <section className="ui card">

            <a className='ui cardImg'>
                <img src={props} />
            </a>

        </section>

            <div className="ui container four column grid">
            <section className="ui card">
                <a href='' className='avatar'>
                    <img src={props.picture} alt='img'/>
                </a>
                <p className='text'>Stay up to date on vaccinations</p>
                <p className='text'>It's very important to kept your pet up to date on vaccinations.</p>
            </section>
        </div>

            {/* <Card.Content>
                <Card.Header>Daniel</Card.Header>
                <Card.Meta>Joined in 2016</Card.Meta>
                <Card.Description>
                    Daniel is a comedian living in Nashville.
                </Card.Description>
            </Card.Content>

        </div>
    )
}
*/





export default card_content